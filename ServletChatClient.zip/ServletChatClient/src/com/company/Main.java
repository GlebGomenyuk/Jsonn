package com.company;

import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Gson gson = new Gson();
        Enty enty = new Enty();
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("Enter your login: ");
            String login = scanner.nextLine();
            System.out.println("Enter your pass: ");
            String pass = scanner.nextLine();

            User user = new User(login, pass);
            int resLog = user.send(Utils.getURL() + "/log");
            if (resLog != 200) { // 200 OK
                System.out.println("HTTP error occured: " + resLog);
                return;
            }
            enty.enty(login);


            if (login.equals("Gleb")) {
                Thread th = new Thread(new GetThread());
                th.setDaemon(true);
                th.start();
                System.out.println("Enter your message: ");
                while (true) {
                    String text = scanner.nextLine();
                    if (text.isEmpty()) break;
                    text = "lol";

                    Message m = new Message(login, text);
                    int res = m.send(Utils.getURL() + "/add");
                    if (res != 200) { // 200 OK
                        System.out.println("HTTP error occured: " + res);
                        return;
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            scanner.close();
        }
    }


    private static byte[] responseBodyToArray(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[10240];
        int r;

        do {
            r = is.read(buf);
            if (r > 0) bos.write(buf, 0, r);
        } while (r != -1);

        return bos.toByteArray();
    }
}
